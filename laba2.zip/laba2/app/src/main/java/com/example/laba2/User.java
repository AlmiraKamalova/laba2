package com.example.laba2;

public class User {

    String poroda, group, color, ves, country;
    int imageId;

    public User(String poroda, String group, String color, String ves, String country, int imageId) {
        this.poroda = poroda;
        this.group = group;
        this.color = color;
        this.ves = ves;
        this.country = country;
        this.imageId = imageId;
    }
}
