package com.example.laba2;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.laba2.databinding.ActivityUserBinding;

public class UserActivity extends AppCompatActivity {

    ActivityUserBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = this.getIntent();

        if (intent != null){

            String poroda = intent.getStringExtra("poroda");
            String ves = intent.getStringExtra("ves");
            String country = intent.getStringExtra("country");
            int imageid = intent.getIntExtra("imageid", R.drawable.a);

            binding.porodaProfile.setText(poroda);
            binding.vesProfile.setText(ves);
            binding.countryProfile.setText(country);
            binding.profileImage.setImageResource(imageid);

        }

    }
}